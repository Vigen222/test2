import { convertPrice } from "../data/currency.js";
import { Heart, MapPin, CarIllustration } from "./Icons.jsx";

// ─── PRICE DISPLAY ────────────────────────────────────────────────────────────
function Price({ priceAMD, currency, currencySymbol }) {
  return (
    <div className="car-price">
      <span className="sym">{currencySymbol}</span>
      {convertPrice(priceAMD, currency)}
      {currency !== "AMD" && <span className="curr-tag">{currency}</span>}
    </div>
  );
}

// ─── BADGE ────────────────────────────────────────────────────────────────────
function Badge({ badge, lang }) {
  if (!badge) return null;
  const labels = {
    new: { ru: "Новый",    en: "New",  hy: "Nor"   },
    hot: { ru: "Горячий",  en: "Hot",  hy: "Tezh"  },
  };
  return <span className={`cbadge ${badge}`}>{labels[badge][lang]}</span>;
}

// ─── DATE LABEL ───────────────────────────────────────────────────────────────
function dateLabel(daysAgo, t) {
  if (daysAgo === 0) return t.today;
  if (daysAgo === 1) return t.yesterday;
  return `${daysAgo} ${t.daysAgo}`;
}

// ─── GRID CARD ────────────────────────────────────────────────────────────────
export function CarCardGrid({ car, lang, currency, currencySymbol, isFav, toggleFav, t }) {
  return (
    <div style={styles.card}>
      <div className="card-img">
        <CarIllustration />
        <Badge badge={car.badge} lang={lang} />
        <button className="fav-btn" onClick={(e) => toggleFav(car.id, e)}>
          <Heart filled={isFav(car.id)} />
        </button>
      </div>
      <div className="card-body">
        <div className="car-name">{car.make} {car.model} {car.year}</div>
        <Price priceAMD={car.priceAMD} currency={currency} currencySymbol={currencySymbol} />
        <div className="chips">
          <span className="chip">{car.km.toLocaleString()} {t.km}</span>
          <span className="chip">{car.engine}</span>
          <span className="chip">{car.trans[lang]}</span>
          <span className="chip">{car.fuel[lang]}</span>
        </div>
        <div className="card-foot">
          <span className="loc"><MapPin /> {car.city[lang]}</span>
          <span className="cdate">{dateLabel(car.daysAgo, t)}</span>
        </div>
      </div>
    </div>
  );
}

// ─── LIST CARD ────────────────────────────────────────────────────────────────
export function CarCardList({ car, lang, currency, currencySymbol, isFav, toggleFav, t }) {
  return (
    <div style={styles.listCard}>
      <div className="card-img" style={styles.listImg}>
        <CarIllustration />
        <Badge badge={car.badge} lang={lang} />
      </div>
      <div className="card-body" style={{ flex: 1, display: "flex", flexDirection: "column", justifyContent: "space-between" }}>
        <div>
          <div className="car-name">{car.make} {car.model} {car.year}</div>
          <Price priceAMD={car.priceAMD} currency={currency} currencySymbol={currencySymbol} />
          <div className="chips">
            <span className="chip">{car.km.toLocaleString()} {t.km}</span>
            <span className="chip">{car.engine}</span>
            <span className="chip">{car.trans[lang]}</span>
            <span className="chip">{car.fuel[lang]}</span>
          </div>
        </div>
        <div className="card-foot">
          <span className="loc"><MapPin /> {car.city[lang]}</span>
          <button
            onClick={(e) => toggleFav(car.id, e)}
            style={styles.favListBtn}
          >
            <Heart filled={isFav(car.id)} />
            {isFav(car.id) ? t.remFav : t.addFav}
          </button>
          <span className="cdate">{dateLabel(car.daysAgo, t)}</span>
        </div>
      </div>
    </div>
  );
}

const styles = {
  card: {
    background: "white", borderRadius: 12,
    border: "1px solid var(--border)", overflow: "hidden",
    cursor: "pointer", transition: "all .22s",
    boxShadow: "0 2px 10px rgba(0,0,0,0.04)",
  },
  listCard: {
    background: "white", borderRadius: 12,
    border: "1px solid var(--border)", display: "flex",
    overflow: "hidden", cursor: "pointer", transition: "all .2s",
    boxShadow: "0 2px 10px rgba(0,0,0,0.04)",
  },
  listImg: { width: 220, height: 148, flexShrink: 0, borderRadius: 0 },
  favListBtn: {
    background: "none", border: "1.5px solid var(--border)",
    borderRadius: 7, padding: "5px 11px", fontSize: 12,
    cursor: "pointer", fontFamily: "'DM Sans',sans-serif",
    fontWeight: 600, display: "flex", alignItems: "center", gap: 5,
  },
};
