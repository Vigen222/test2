import { useState } from "react";

export default function AuthModal({ isOpen, onClose, initialTab = "login", t }) {
  const [tab, setTab] = useState(initialTab);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [error, setError] = useState("");
  const [success, setSuccess] = useState("");

  if (!isOpen) return null;

  function switchTab(newTab) {
    setTab(newTab);
    setError("");
    setSuccess("");
    setPassword("");
    setConfirmPassword("");
  }

  function handleSubmit(e) {
    e.preventDefault();
    setError("");
    setSuccess("");

    if (!email || !password) {
      setError(tab === "login" ? "Заполните все поля" : "Заполните все поля");
      return;
    }

    if (tab === "register") {
      if (password !== confirmPassword) {
        setError("Пароли не совпадают");
        return;
      }
      if (password.length < 6) {
        setError("Пароль минимум 6 символов");
        return;
      }
      setSuccess("Аккаунт создан! Теперь войдите.");
      switchTab("login");
      return;
    }

    // Mock login
    if (email === "test@test.com" && password === "123456") {
      setSuccess("Вы вошли успешно!");
      setTimeout(() => {
        onClose();
        setSuccess("");
        setEmail("");
        setPassword("");
      }, 1200);
    } else {
      setError("Неверный email или пароль");
    }
  }

  return (
    <>
      <div style={styles.overlay} onClick={onClose} />
      <div style={styles.modal}>
        <button style={styles.closeBtn} onClick={onClose}>✕</button>

        {/* Logo */}
        <div style={styles.logoRow}>
          <div style={styles.logoMark}>
            <svg width="22" height="22" viewBox="0 0 24 24" fill="white">
              <path d="M18.92 6.01C18.72 5.42 18.16 5 17.5 5h-11c-.66 0-1.21.42-1.42 1.01L3 12v8c0 .55.45 1 1 1h1c.55 0 1-.45 1-1v-1h12v1c0 .55.45 1 1 1h1c.55 0 1-.45 1-1v-8l-2.08-5.99zM6.5 16c-.83 0-1.5-.67-1.5-1.5S5.67 13 6.5 13s1.5.67 1.5 1.5S7.33 16 6.5 16zm11 0c-.83 0-1.5-.67-1.5-1.5s.67-1.5 1.5-1.5 1.5.67 1.5 1.5-.67 1.5-1.5 1.5zM5 11l1.5-4.5h11L19 11H5z"/>
            </svg>
          </div>
          <span style={styles.logoText}>
            Hay<span style={{ color: "var(--orange)" }}>Drive</span>
          </span>
        </div>

        {/* Tabs */}
        <div style={styles.tabs}>
          <button
            style={{ ...styles.tab, ...(tab === "login" ? styles.tabActive : {}) }}
            onClick={() => switchTab("login")}
          >
            {t?.login || "Войти"}
          </button>
          <button
            style={{ ...styles.tab, ...(tab === "register" ? styles.tabActive : {}) }}
            onClick={() => switchTab("register")}
          >
            {t?.register || "Регистрация"}
          </button>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} style={styles.form}>
          <div style={styles.field}>
            <label style={styles.label}>Email</label>
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="example@mail.com"
              style={styles.input}
            />
          </div>

          <div style={styles.field}>
            <label style={styles.label}>Пароль</label>
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="••••••••"
              style={styles.input}
            />
          </div>

          {tab === "register" && (
            <div style={styles.field}>
              <label style={styles.label}>Повторите пароль</label>
              <input
                type="password"
                value={confirmPassword}
                onChange={(e) => setConfirmPassword(e.target.value)}
                placeholder="••••••••"
                style={styles.input}
              />
            </div>
          )}

          {error   && <div style={styles.errorBox}>{error}</div>}
          {success && <div style={styles.successBox}>{success}</div>}

          {tab === "login" && (
            <div style={styles.hint}>Тест: test@test.com / 123456</div>
          )}

          <button type="submit" style={styles.submitBtn}>
            {tab === "login" ? (t?.login || "Войти") : (t?.register || "Зарегистрироваться")}
          </button>

          <p style={styles.switchText}>
            {tab === "login" ? "Нет аккаунта? " : "Уже есть аккаунт? "}
            <span
              style={styles.switchLink}
              onClick={() => switchTab(tab === "login" ? "register" : "login")}
            >
              {tab === "login" ? (t?.register || "Регистрация") : (t?.login || "Войти")}
            </span>
          </p>
        </form>
      </div>
    </>
  );
}

const styles = {
  overlay: {
    position: "fixed", inset: 0,
    background: "rgba(0,0,0,0.72)",
    zIndex: 999, backdropFilter: "blur(4px)",
  },
  modal: {
    position: "fixed", top: "50%", left: "50%",
    transform: "translate(-50%, -50%)",
    zIndex: 1000,
    background: "#1A1512",
    border: "1px solid rgba(255,255,255,0.08)",
    borderRadius: 16, padding: "36px 40px",
    width: "100%", maxWidth: 400,
    boxShadow: "0 24px 80px rgba(0,0,0,0.7)",
  },
  closeBtn: {
    position: "absolute", top: 14, right: 16,
    background: "transparent", border: "none",
    color: "rgba(255,255,255,0.4)", fontSize: 18,
    cursor: "pointer", padding: "4px 8px", borderRadius: 6, lineHeight: 1,
  },
  logoRow: { display: "flex", alignItems: "center", gap: 10, marginBottom: 24 },
  logoMark: {
    width: 38, height: 38, background: "var(--red)", borderRadius: 9,
    display: "flex", alignItems: "center", justifyContent: "center",
    boxShadow: "0 4px 14px rgba(184,50,40,0.44)",
  },
  logoText: {
    fontFamily: "'Playfair Display', serif",
    fontSize: 22, fontWeight: 900, color: "white",
  },
  tabs: {
    display: "flex", background: "rgba(255,255,255,0.05)",
    borderRadius: 10, padding: 4, marginBottom: 24, gap: 4,
  },
  tab: {
    flex: 1, padding: "9px 0", border: "none",
    background: "transparent", color: "rgba(255,255,255,0.5)",
    fontSize: 14, fontWeight: 600, borderRadius: 7,
    cursor: "pointer", transition: "all .2s",
    fontFamily: "'DM Sans', sans-serif",
  },
  tabActive: {
    background: "var(--red)", color: "#fff",
    boxShadow: "0 2px 10px rgba(184,50,40,0.4)",
  },
  form: { display: "flex", flexDirection: "column", gap: 16 },
  field: { display: "flex", flexDirection: "column", gap: 6 },
  label: {
    fontSize: 13, color: "rgba(255,255,255,0.6)",
    fontWeight: 500, fontFamily: "'DM Sans', sans-serif",
  },
  input: {
    background: "rgba(255,255,255,0.06)",
    border: "1px solid rgba(255,255,255,0.12)",
    borderRadius: 9, padding: "11px 14px",
    color: "#fff", fontSize: 14,
    fontFamily: "'DM Sans', sans-serif", outline: "none",
  },
  errorBox: {
    background: "rgba(184,50,40,0.15)",
    border: "1px solid rgba(184,50,40,0.4)",
    borderRadius: 8, padding: "9px 13px",
    color: "#FF9080", fontSize: 13,
    fontFamily: "'DM Sans', sans-serif",
  },
  successBox: {
    background: "rgba(40,184,80,0.15)",
    border: "1px solid rgba(40,184,80,0.4)",
    borderRadius: 8, padding: "9px 13px",
    color: "#60e080", fontSize: 13,
    fontFamily: "'DM Sans', sans-serif",
  },
  hint: {
    fontSize: 12, color: "rgba(255,255,255,0.3)",
    fontFamily: "'DM Sans', sans-serif", textAlign: "center",
  },
  submitBtn: {
    background: "var(--red)", color: "#fff", border: "none",
    borderRadius: 9, padding: "12px 0",
    fontSize: 15, fontWeight: 700, cursor: "pointer",
    fontFamily: "'DM Sans', sans-serif", marginTop: 4,
    boxShadow: "0 4px 16px rgba(184,50,40,0.4)",
  },
  switchText: {
    textAlign: "center", fontSize: 13,
    color: "rgba(255,255,255,0.4)",
    fontFamily: "'DM Sans', sans-serif", margin: 0,
  },
  switchLink: { color: "var(--orange)", cursor: "pointer", fontWeight: 600 },
};
