import { BRANDS, BODY_TYPE_COUNTS, ENGINE_OPTIONS, MILEAGE_OPTIONS, TRANSMISSION_OPTIONS } from "../data/listings.js";
import { CURRENCY_SYMBOLS } from "../data/currency.js";

export default function Sidebar({ t, lang, currency, activeCat, setActiveCat, selBrands, toggleBrand }) {
  const sym = CURRENCY_SYMBOLS[currency];

  return (
    <aside style={styles.sidebar}>

      {/* Body type */}
      <div className="sc">
        <div className="sc-h"><div className="dot" />{t.bodyType}</div>
        <div className="sc-b">
          <ul style={{ listStyle: "none" }}>
            {t.bodyTypes.map((name, i) => (
              <li
                key={i}
                style={{
                  ...styles.catItem,
                  ...(activeCat === i ? styles.catItemActive : {}),
                }}
                onClick={() => setActiveCat(i)}
              >
                <span>{name}</span>
                <span style={{ ...styles.catCount, ...(activeCat === i ? styles.catCountActive : {}) }}>
                  {BODY_TYPE_COUNTS[i]}
                </span>
              </li>
            ))}
          </ul>
        </div>
      </div>

      {/* Price range */}
      <div className="sc">
        <div className="sc-h"><div className="dot" />{t.price} — {sym}</div>
        <div className="sc-b">
          <div style={styles.priceRow}>
            <input
              className="inp"
              type="number"
              placeholder={lang === "ru" ? "От" : lang === "en" ? "Min" : "Min"}
            />
            <input
              className="inp"
              type="number"
              placeholder={lang === "ru" ? "До" : lang === "en" ? "Max" : "Max"}
            />
          </div>
          <button className="apply-btn">{t.apply}</button>
        </div>
      </div>

      {/* Car brands */}
      <div className="sc">
        <div className="sc-h"><div className="dot" />{t.carMakes}</div>
        <div className="sc-b">
          <div style={styles.brandsGrid}>
            {BRANDS.map((brand) => (
              <button
                key={brand}
                style={{
                  ...styles.brandBtn,
                  ...(selBrands.includes(brand) ? styles.brandBtnActive : {}),
                }}
                onClick={() => toggleBrand(brand)}
              >
                {brand}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Extra filters */}
      <div className="sc">
        <div className="sc-h"><div className="dot" />{t.filters}</div>
        <div className="sc-b">
          <span className="flabel">{t.engine}</span>
          <select className="fsel">
            <option>—</option>
            {ENGINE_OPTIONS.map((o) => <option key={o}>{o}</option>)}
          </select>

          <span className="flabel">{t.mileage}</span>
          <select className="fsel">
            <option>—</option>
            {MILEAGE_OPTIONS[lang].map((o) => <option key={o}>{o}</option>)}
          </select>

          <span className="flabel">{t.transmission}</span>
          <select className="fsel">
            <option>—</option>
            {TRANSMISSION_OPTIONS[lang].map((o) => <option key={o}>{o}</option>)}
          </select>

          <button className="apply-btn">{t.applyFilters}</button>
        </div>
      </div>

    </aside>
  );
}

const styles = {
  sidebar: { display: "flex", flexDirection: "column", gap: 14 },

  catItem: {
    display: "flex", justifyContent: "space-between", alignItems: "center",
    padding: "7px 9px", borderRadius: 7, cursor: "pointer",
    fontSize: 13, fontWeight: 500, transition: "background .13s",
  },
  catItemActive: { background: "#FDEDEA", color: "var(--red)", fontWeight: 700 },

  catCount: {
    background: "var(--lgray)", color: "var(--gray)",
    fontSize: 11, padding: "2px 8px", borderRadius: 10, fontWeight: 700,
  },
  catCountActive: { background: "var(--red)", color: "white" },

  priceRow: { display: "grid", gridTemplateColumns: "1fr 1fr", gap: 8, marginBottom: 10 },

  brandsGrid: { display: "grid", gridTemplateColumns: "1fr 1fr", gap: 6 },
  brandBtn: {
    background: "var(--lgray)", border: "1.5px solid transparent",
    borderRadius: 7, padding: "7px 10px", fontSize: 12, fontWeight: 600,
    cursor: "pointer", textAlign: "center",
    fontFamily: "'DM Sans', sans-serif", color: "var(--dark)",
    transition: "all .13s",
  },
  brandBtnActive: { borderColor: "var(--red)", background: "var(--red)", color: "white" },
};
