import { useState } from "react";
import { CURRENCIES, CURRENCY_LABELS } from "../data/currency.js";
import { LANGUAGES, LANG_LABELS } from "../data/translations.js";
import { Exchange, Phone, Heart, NAV_ICONS, LogoCar } from "./Icons.jsx";
import AuthModal from "./AuthModal.jsx";

export default function Header({ t, lang, setLang, currency, setCurrency, favs, activeNav, setActiveNav, addListingClick }) {
  const [authOpen, setAuthOpen] = useState(false);
  const [authTab,  setAuthTab]  = useState("login");

  function openLogin()    { setAuthTab("login");    setAuthOpen(true); }
  function openRegister() { setAuthTab("register"); setAuthOpen(true); }

  return (
    <>
      <header style={styles.header}>

        {/* ── TOP STRIPE ── */}
        <div style={styles.topBar}>
          <div style={styles.topLeft}>
            <ArmFlag />
            <span>{t.country}</span>
            <span style={styles.phone}><Phone /> {t.phone}</span>
          </div>

          <div style={styles.topRight}>
            {/* Currency switcher */}
            <div className="pill-wrap">
              <span className="pill-label"><Exchange /> {t.currency}</span>
              {CURRENCIES.map((c) => (
                <button
                  key={c}
                  className={`pill-btn ${currency === c ? "pill-curr-on" : ""}`}
                  onClick={() => setCurrency(c)}
                >
                  {CURRENCY_LABELS[c]}
                </button>
              ))}
            </div>

            {/* Language switcher */}
            <div className="pill-wrap">
              {LANGUAGES.map((l) => (
                <button
                  key={l}
                  className={`pill-btn ${lang === l ? "pill-lang-on" : ""}`}
                  onClick={() => setLang(l)}
                >
                  {LANG_LABELS[l]}
                </button>
              ))}
            </div>


          </div>
        </div>

        {/* ── MAIN NAV ROW ── */}
        <div style={styles.mainRow}>
          <a style={styles.logo}>
            <div style={styles.logoMark}><LogoCar /></div>
            <div style={styles.logoText}>
              <span style={styles.logoName}>
                Hay<span style={{ color: "var(--orange)" }}>Drive</span>
              </span>
              <span style={styles.logoSub}>Armenia's Car Market</span>
            </div>
          </a>

          <nav style={styles.nav}>
            {t.nav.map((label, i) => {
              const Icon = NAV_ICONS[i];
              return (
                <button
                  key={i}
                  style={{ ...styles.navBtn, ...(activeNav === i ? styles.navBtnActive : {}) }}
                  onClick={() => setActiveNav(i)}
                >
                  <Icon /> {label}
                </button>
              );
            })}
          </nav>

          <div style={styles.actions}>
            <button style={styles.loginBtn} onClick={openLogin}>
              {t.login}
            </button>

            <button style={styles.registerBtn} onClick={openRegister}>
              {t.register}
            </button>
          </div>
        </div>
      </header>

      <AuthModal
        isOpen={authOpen}
        onClose={() => setAuthOpen(false)}
        initialTab={authTab}
        t={t}
      />
    </>
  );
}

/* ── Flag ── */
function ArmFlag() {
  return (
    <div className="flag">
      <div className="flag-stripe r" />
      <div className="flag-stripe b" />
      <div className="flag-stripe o" />
    </div>
  );
}

const styles = {
  header: {
    background: "#0F0C0A",
    borderBottom: "3px solid var(--red)",
    position: "sticky", top: 0, zIndex: 200,
    boxShadow: "0 2px 28px rgba(0,0,0,0.55)",
  },
  topBar: {
    background: "linear-gradient(90deg, #7A1810, var(--red) 50%, #7A1810)",
    padding: "5px 24px",
    display: "flex", justifyContent: "space-between", alignItems: "center",
    fontSize: 12, color: "rgba(255,255,255,0.9)", fontWeight: 500,
  },
  topLeft:  { display: "flex", alignItems: "center", gap: 12 },
  topRight: { display: "flex", alignItems: "center", gap: 14 },
  phone:    { display: "flex", alignItems: "center", gap: 5, opacity: .82 },
  auth:     { display: "flex", alignItems: "center", gap: 6 },
  authLink: { cursor: "pointer", fontWeight: 700, textDecoration: "underline", textUnderlineOffset: 2 },
  authSep:  { opacity: .38 },

  mainRow: {
    display: "flex", alignItems: "center",
    padding: "13px 24px", gap: 22,
    maxWidth: 1320, margin: "0 auto",
  },
  logo:     { display: "flex", alignItems: "center", gap: 11, textDecoration: "none", flexShrink: 0, cursor: "pointer" },
  logoMark: { width: 44, height: 44, background: "var(--red)", borderRadius: 11, display: "flex", alignItems: "center", justifyContent: "center", boxShadow: "0 4px 14px rgba(184,50,40,0.44)" },
  logoText: { lineHeight: 1 },
  logoName: { fontFamily: "'Playfair Display', serif", fontSize: 26, fontWeight: 900, color: "white", letterSpacing: -.5, display: "block" },
  logoSub:  { fontSize: 9.5, color: "rgba(255,255,255,0.36)", fontWeight: 500, letterSpacing: 2, textTransform: "uppercase", marginTop: 2, display: "block" },

  nav: { display: "flex", gap: 2, flex: 1 },
  navBtn: {
    color: "rgba(255,255,255,0.68)", fontSize: 13, fontWeight: 500,
    padding: "8px 11px", borderRadius: 7, transition: "all .17s",
    whiteSpace: "nowrap", cursor: "pointer", border: "none",
    background: "transparent", fontFamily: "'DM Sans', sans-serif",
    display: "flex", alignItems: "center", gap: 6,
  },
  navBtnActive: { background: "rgba(184,50,40,.2)", color: "#FF9080" },

  actions: { display: "flex", gap: 10, alignItems: "center" },

  loginBtn: {
    background: "transparent",
    color: "rgba(255,255,255,0.85)",
    border: "1px solid rgba(255,255,255,0.25)",
    borderRadius: 8, padding: "8px 18px",
    fontSize: 13, fontWeight: 600, cursor: "pointer",
    fontFamily: "'DM Sans', sans-serif", whiteSpace: "nowrap",
  },
  registerBtn: {
    background: "var(--red)", color: "#fff", border: "none",
    borderRadius: 8, padding: "8px 18px",
    fontSize: 13, fontWeight: 700, cursor: "pointer",
    fontFamily: "'DM Sans', sans-serif", whiteSpace: "nowrap",
  },
};
