export default function StatsBar({ t }) {
  const stats = [
    ["24 891", t.statCars],
    ["1 204",  t.statToday],
    ["892",    t.statSellers],
    ["15+",    t.statCities],
  ];

  return (
    <div style={styles.bar}>
      {stats.map(([num, label]) => (
        <div key={label} style={styles.item}>
          <span style={styles.num}>{num}</span>
          <span style={styles.label}>{label}</span>
        </div>
      ))}
    </div>
  );
}

const styles = {
  bar: {
    background: "linear-gradient(90deg, #8C2018, var(--red) 50%, #8C2018)",
    padding: "14px 20px",
    display: "flex", justifyContent: "center",
  },
  item: {
    display: "flex", flexDirection: "column", alignItems: "center",
    color: "white", padding: "0 36px",
    borderRight: "1px solid rgba(255,255,255,0.18)",
  },
  num: {
    fontFamily: "'Playfair Display', serif",
    fontSize: 22, fontWeight: 700, lineHeight: 1,
  },
  label: {
    fontSize: 10, opacity: .78,
    textTransform: "uppercase", letterSpacing: .8,
    marginTop: 2, fontWeight: 500,
  },
};
