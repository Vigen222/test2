import { CARS, FEATURED_CARS } from "../data/listings.js";
import { convertPrice } from "../data/currency.js";
import { CarCardGrid, CarCardList } from "./CarCard.jsx";
import { CarIllustration, Star, GridIcon, ListIcon } from "./Icons.jsx";

export default function Listings({ t, lang, currency, currencySymbol, view, setView, isFav, toggleFav, page, setPage }) {

  return (
    <main style={{ flex: 1 }}>

      {/* ── FEATURED ── */}
      <Featured t={t} currency={currency} currencySymbol={currencySymbol} />

      {/* ── LISTINGS HEADER ── */}
      <div style={styles.listHeader}>
        <div>
          <div style={styles.listTitle}>
            {t.totalListings}: <span style={{ color: "var(--red)" }}>24 891</span>
          </div>
          <div style={styles.listSub}>{t.newAdded}</div>
        </div>
        <div style={{ display: "flex", gap: 10, alignItems: "center" }}>
          <select style={styles.sortSel}>
            <option>{t.sortNew}</option>
            <option>{t.sortPriceUp}</option>
            <option>{t.sortPriceDown}</option>
            <option>{t.sortMileage}</option>
          </select>
          <div style={styles.viewTog}>
            <button style={{ ...styles.viewBtn, ...(view === "grid" ? styles.viewBtnOn : {}) }} onClick={() => setView("grid")}><GridIcon /></button>
            <button style={{ ...styles.viewBtn, ...(view === "list" ? styles.viewBtnOn : {}) }} onClick={() => setView("list")}><ListIcon /></button>
          </div>
        </div>
      </div>

      {/* ── CARDS ── */}
      {view === "grid" ? (
        <div style={styles.grid}>
          {CARS.map((car) => (
            <CarCardGrid
              key={car.id} car={car} lang={lang}
              currency={currency} currencySymbol={currencySymbol}
              isFav={isFav} toggleFav={toggleFav} t={t}
            />
          ))}
        </div>
      ) : (
        <div style={styles.listView}>
          {CARS.map((car) => (
            <CarCardList
              key={car.id} car={car} lang={lang}
              currency={currency} currencySymbol={currencySymbol}
              isFav={isFav} toggleFav={toggleFav} t={t}
            />
          ))}
        </div>
      )}

      {/* ── PAGINATION ── */}
      <div className="pages">
        <button className="pg-btn">&#8249;</button>
        {[1, 2, 3, 4, 5].map((p) => (
          <button key={p} className={`pg-btn ${page === p ? "on" : ""}`} onClick={() => setPage(p)}>{p}</button>
        ))}
        <button className="pg-btn">…</button>
        <button className="pg-btn">124</button>
        <button className="pg-btn">&#8250;</button>
      </div>
    </main>
  );
}

// ── FEATURED SECTION ──────────────────────────────────────────────────────────
function Featured({ t, currency, currencySymbol }) {
  return (
    <div style={styles.featured}>
      <div style={styles.featHeader}>
        <Star /> {t.featured}
      </div>
      <div style={styles.featGrid}>
        {FEATURED_CARS.map((fc) => (
          <div key={fc.id} style={styles.featCard}>
            <div style={styles.featImg}><CarIllustration /></div>
            <div style={styles.featInfo}>
              <div style={styles.featName}>{fc.name}</div>
              <div style={styles.featPrice}>
                {currencySymbol}{convertPrice(fc.priceAMD, currency)}
                {currency !== "AMD" && <span className="curr-tag">{currency}</span>}
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

const styles = {
  featured: {
    background: "white", borderRadius: 12,
    border: "1px solid var(--border)", padding: 16,
    marginBottom: 20, borderLeft: "4px solid var(--gold)",
    boxShadow: "0 2px 10px rgba(0,0,0,0.04)",
  },
  featHeader: {
    display: "flex", alignItems: "center", gap: 7,
    marginBottom: 14, fontWeight: 800, fontSize: 12,
    color: "var(--dark)", textTransform: "uppercase", letterSpacing: .9,
  },
  featGrid: { display: "grid", gridTemplateColumns: "repeat(3,1fr)", gap: 12 },
  featCard: {
    border: "1px solid var(--border)", borderRadius: 10,
    overflow: "hidden", cursor: "pointer", transition: "all .17s",
  },
  featImg: {
    width: "100%", height: 100,
    background: "linear-gradient(135deg, #EDE5D8 0%, #D5C9B4 100%)",
    display: "flex", alignItems: "center", justifyContent: "center",
  },
  featInfo: { padding: 10 },
  featName: { fontSize: 12, fontWeight: 700, marginBottom: 3, color: "var(--dark)" },
  featPrice: { fontSize: 14, fontWeight: 800, color: "var(--red)", fontFamily: "'Playfair Display', serif" },

  listHeader: {
    display: "flex", justifyContent: "space-between", alignItems: "center",
    marginBottom: 18, flexWrap: "wrap", gap: 12,
  },
  listTitle: { fontFamily: "'Playfair Display', serif", fontSize: 22, fontWeight: 700 },
  listSub:   { color: "var(--gray)", fontSize: 12, marginTop: 2 },

  sortSel: {
    border: "1.5px solid var(--border)", borderRadius: 8,
    padding: "8px 13px", fontSize: 13, outline: "none",
    background: "white", fontFamily: "'DM Sans', sans-serif", fontWeight: 500, cursor: "pointer",
  },

  viewTog: { display: "flex", gap: 4 },
  viewBtn: {
    background: "var(--lgray)", border: "none",
    padding: "8px 11px", borderRadius: 7, cursor: "pointer",
    color: "var(--gray)", display: "flex", alignItems: "center", justifyContent: "center",
    transition: "all .13s",
  },
  viewBtnOn: { background: "var(--red)", color: "white" },

  grid:     { display: "grid", gridTemplateColumns: "repeat(2,1fr)", gap: 18 },
  listView: { display: "flex", flexDirection: "column", gap: 14 },
};
