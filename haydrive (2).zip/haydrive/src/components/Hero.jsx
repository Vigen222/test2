import { BRANDS, CITIES, YEARS } from "../data/listings.js";
import { maxPricePlaceholder } from "../data/currency.js";
import { Search } from "./Icons.jsx";

export default function Hero({ t, lang, currency, currencySymbol }) {
  const maxPH = maxPricePlaceholder(currency);

  return (
    <div style={styles.hero}>
      {/* radial glow overlay */}
      <div style={styles.overlay} />

      <div style={styles.inner}>
        {/* Eyebrow */}
        <div style={styles.eyebrow}>
          <span style={styles.eyebrowDot} />
          HayDrive —{" "}
          {lang === "ru" ? "Авторынок Армении"
            : lang === "en" ? "Armenian Car Market"
            : "Hayastani avtobaznerin shuka"}
        </div>

        {/* Title */}
        <div style={styles.title}>
          {t.heroTitle}{" "}
          <em style={{ color: "var(--orange)", fontStyle: "italic" }}>
            {t.heroTitleSpan}
          </em>
          <br />
          {t.heroTitle2}
        </div>

        <div style={styles.subtitle}>{t.heroSub}</div>

        {/* Search box */}
        <div style={styles.searchBox}>
          <Field label={t.make}>
            <select style={styles.ctrl}>
              <option>{t.allMakes}</option>
              {BRANDS.map((b) => <option key={b}>{b}</option>)}
            </select>
          </Field>

          <Field label={t.model}>
            <select style={styles.ctrl}><option>{t.allModels}</option></select>
          </Field>

          <Field label={t.yearFrom}>
            <select style={styles.ctrl}>
              <option>—</option>
              {YEARS.map((y) => <option key={y}>{y}</option>)}
            </select>
          </Field>

          <Field label={t.yearTo}>
            <select style={styles.ctrl}>
              <option>—</option>
              {YEARS.map((y) => <option key={y}>{y}</option>)}
            </select>
          </Field>

          <Field label={`${t.priceMin} (${currencySymbol})`}>
            <input type="number" placeholder="0" style={styles.ctrl} />
          </Field>

          <Field label={`${t.priceMax} (${currencySymbol})`}>
            <input type="number" placeholder={maxPH} style={styles.ctrl} />
          </Field>

          <Field label={t.city}>
            <select style={styles.ctrl}>
              {CITIES[lang].map((c) => <option key={c}>{c}</option>)}
            </select>
          </Field>

          <button style={styles.searchBtn}>
            <Search /> {t.search}
          </button>
        </div>
      </div>
    </div>
  );
}

function Field({ label, children }) {
  return (
    <div style={styles.field}>
      <label style={styles.fieldLabel}>{label}</label>
      {children}
    </div>
  );
}

const styles = {
  hero: {
    background: "linear-gradient(135deg, #0E0A08 0%, #28100A 45%, #160806 100%)",
    position: "relative", overflow: "hidden",
    padding: "56px 24px 44px",
  },
  overlay: {
    position: "absolute", inset: 0,
    background: "radial-gradient(ellipse at 74% 50%, rgba(184,50,40,0.1) 0%, transparent 55%), radial-gradient(ellipse at 18% 80%, rgba(217,136,40,0.06) 0%, transparent 45%)",
    pointerEvents: "none",
  },
  inner: { maxWidth: 1320, margin: "0 auto", position: "relative", zIndex: 1 },

  eyebrow: {
    display: "inline-flex", alignItems: "center", gap: 8,
    background: "rgba(184,50,40,0.13)",
    border: "1px solid rgba(184,50,40,0.27)",
    borderRadius: 20, padding: "5px 14px",
    fontSize: 12, color: "#FF8878", fontWeight: 600,
    letterSpacing: .4, marginBottom: 18,
  },
  eyebrowDot: { width: 6, height: 6, borderRadius: "50%", background: "var(--red)", flexShrink: 0 },

  title: {
    fontFamily: "'Playfair Display', serif",
    fontSize: 50, fontWeight: 900, color: "white",
    lineHeight: 1.08, letterSpacing: -1, marginBottom: 10,
  },
  subtitle: { color: "rgba(255,255,255,0.42)", fontSize: 15, marginBottom: 32, fontWeight: 300 },

  searchBox: {
    background: "white", borderRadius: 14, padding: 20,
    display: "flex", gap: 11, alignItems: "flex-end", flexWrap: "wrap",
    boxShadow: "0 22px 60px rgba(0,0,0,0.5)",
    borderTop: "3px solid var(--red)",
  },
  field: { display: "flex", flexDirection: "column", gap: 6, minWidth: 120, flex: 1 },
  fieldLabel: { fontSize: 10, fontWeight: 700, color: "var(--gray)", textTransform: "uppercase", letterSpacing: .8 },
  ctrl: {
    border: "1.5px solid var(--border)", borderRadius: 8,
    padding: "10px 11px", fontSize: 13, color: "var(--dark)",
    background: "var(--cream)", outline: "none",
    fontFamily: "'DM Sans', sans-serif", width: "100%",
  },
  searchBtn: {
    background: "var(--red)", color: "white", border: "none",
    padding: "12px 30px", borderRadius: 8,
    fontSize: 14, fontWeight: 700, cursor: "pointer",
    fontFamily: "'DM Sans', sans-serif",
    boxShadow: "0 4px 14px rgba(184,50,40,0.36)",
    display: "flex", alignItems: "center", gap: 8,
    whiteSpace: "nowrap",
  },
};
