import { Facebook, Instagram, Telegram, FooterCar } from "./Icons.jsx";

export default function Footer({ t }) {
  const cols = [
    [t.footerCat,    t.footerLinks1],
    [t.footerType,   t.footerLinks2],
    [t.footerClient, t.footerLinks3],
  ];

  return (
    <footer style={styles.footer}>
      <div style={styles.grid}>

        {/* Brand column */}
        <div>
          <div style={styles.logoRow}>
            <div style={styles.mark}><FooterCar /></div>
            <span style={styles.name}>
              Hay<span style={{ color: "var(--orange)" }}>Drive</span>
            </span>
          </div>
          <p style={styles.desc}>{t.footerDesc}</p>
          <div style={styles.socials}>
            {[[Facebook, "fb"], [Instagram, "ig"], [Telegram, "tg"]].map(([Icon, key]) => (
              <button key={key} style={styles.socBtn}><Icon /></button>
            ))}
          </div>
        </div>

        {/* Link columns */}
        {cols.map(([title, links]) => (
          <div key={title}>
            <h4 style={styles.colTitle}>{title}</h4>
            <ul style={styles.links}>
              {links.map((l) => (
                <li key={l}><a href="#" style={styles.link}>{l}</a></li>
              ))}
            </ul>
          </div>
        ))}
      </div>

      {/* Bottom bar */}
      <div style={styles.bottom}>
        <span>{t.copyright}</span>
        <div style={styles.bottomRight}>
          <div style={{ display: "flex", flexDirection: "column", gap: 1.5 }}>
            <div style={{ width: 20, height: 4, background: "#D90012", borderRadius: 1 }} />
            <div style={{ width: 20, height: 4, background: "#0033A0", borderRadius: 1 }} />
            <div style={{ width: 20, height: 4, background: "#F2A800", borderRadius: 1 }} />
          </div>
          Yerevan, Armenia
        </div>
      </div>
    </footer>
  );
}

const styles = {
  footer: {
    background: "#0F0C0A",
    color: "rgba(255,255,255,0.58)",
    padding: "46px 24px 22px",
    marginTop: 50,
  },
  grid: {
    maxWidth: 1320, margin: "0 auto 34px",
    display: "grid", gridTemplateColumns: "2fr 1fr 1fr 1fr", gap: 46,
  },
  logoRow: { display: "flex", alignItems: "center", gap: 10, marginBottom: 12 },
  mark: {
    width: 36, height: 36, background: "var(--red)",
    borderRadius: 8, display: "flex", alignItems: "center", justifyContent: "center",
  },
  name: {
    fontFamily: "'Playfair Display', serif",
    fontSize: 22, fontWeight: 900, color: "white",
  },
  desc: { fontSize: 13, lineHeight: 1.8, color: "rgba(255,255,255,0.38)" },
  socials: { marginTop: 17, display: "flex", gap: 8 },
  socBtn: {
    width: 36, height: 36, borderRadius: 8,
    background: "rgba(255,255,255,0.07)", border: "none",
    display: "flex", alignItems: "center", justifyContent: "center",
    cursor: "pointer", color: "rgba(255,255,255,0.52)",
  },
  colTitle: {
    color: "white", fontSize: 11, fontWeight: 800,
    marginBottom: 14, textTransform: "uppercase", letterSpacing: 1.1,
    fontFamily: "'DM Sans', sans-serif",
  },
  links: { listStyle: "none", display: "flex", flexDirection: "column", gap: 9 },
  link: { color: "rgba(255,255,255,0.42)", textDecoration: "none", fontSize: 13 },
  bottom: {
    maxWidth: 1320, margin: "0 auto",
    paddingTop: 20, borderTop: "1px solid rgba(255,255,255,0.07)",
    display: "flex", justifyContent: "space-between", alignItems: "center",
    fontSize: 12, color: "rgba(255,255,255,0.26)",
  },
  bottomRight: { display: "flex", alignItems: "center", gap: 8 },
};
