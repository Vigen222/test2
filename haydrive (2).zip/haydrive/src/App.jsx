import { useAppState } from "./hooks/useAppState.js";
import T from "./data/translations.js";
import { CURRENCY_SYMBOLS } from "./data/currency.js";

import Header   from "./components/Header.jsx";
import Hero     from "./components/Hero.jsx";
import StatsBar from "./components/StatsBar.jsx";
import Sidebar  from "./components/Sidebar.jsx";
import Listings from "./components/Listings.jsx";
import Footer   from "./components/Footer.jsx";

import "./styles/global.css";

export default function App() {
  const state = useAppState();
  const {
    lang, currency, view, setView,
    activeCat, setActiveCat,
    selBrands, toggleBrand,
    favs, toggleFav, isFav,
    page, setPage,
    activeNav, setActiveNav,
    setLang, setCurrency,
  } = state;

  const t   = T[lang];
  const sym = CURRENCY_SYMBOLS[currency];

  return (
    <>
      <Header
        t={t}
        lang={lang}           setLang={setLang}
        currency={currency}   setCurrency={setCurrency}
        favs={favs}
        activeNav={activeNav} setActiveNav={setActiveNav}
      />
      <Hero
        t={t}
        lang={lang}
        currency={currency}
        currencySymbol={sym}
      />
      <StatsBar t={t} />
      <div style={layoutStyles.body}>
        <Sidebar
          t={t}
          lang={lang}
          currency={currency}
          activeCat={activeCat}   setActiveCat={setActiveCat}
          selBrands={selBrands}   toggleBrand={toggleBrand}
        />
        <Listings
          t={t}
          lang={lang}
          currency={currency}   currencySymbol={sym}
          view={view}           setView={setView}
          isFav={isFav}         toggleFav={toggleFav}
          page={page}           setPage={setPage}
        />
      </div>
      <Footer t={t} />
    </>
  );
}

const layoutStyles = {
  body: {
    maxWidth: 1320,
    margin: "0 auto",
    padding: "28px 24px",
    display: "grid",
    gridTemplateColumns: "262px 1fr",
    gap: 24,
  },
};
