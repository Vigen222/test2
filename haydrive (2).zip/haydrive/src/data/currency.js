export const RATES = { AMD: 1, USD: 0.00026, RUB: 0.024 };

export const CURRENCY_SYMBOLS = { AMD: "֏", USD: "$", RUB: "₽" };

export const CURRENCY_LABELS = { AMD: "֏ AMD", USD: "$ USD", RUB: "₽ RUB" };

export const CURRENCIES = ["AMD", "USD", "RUB"];

export function convertPrice(amd, currency) {
  const val = Math.round(amd * RATES[currency]);
  return val.toLocaleString("ru-RU");
}

export function maxPricePlaceholder(currency) {
  const p = { AMD: "50 000 000", USD: "13 000", RUB: "1 200 000" };
  return p[currency] || "50 000 000";
}
