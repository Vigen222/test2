const T = {
 hy: {
  country: "Հայաստան",
  phone: "+374 10 123 456",
  hello: "Բարև",
  login: "Մուտք",
  register: "Գրանցվել",

  nav: [
    "Ավտոմեքենաներ",
    "Մոտոցիկլետներ",
    "Բեռնատարներ",
    "Ավտոբուսներ",
    "Պահեստամասեր",
    "Էլեկտրամեքենաներ"
  ],

  favorites: "Ընտրյալներ",
  addListing: "+ Ավելացնել հայտարարություն",

  heroTitle: "Գտեք ձեր",
  heroTitleSpan: "կատարյալ",
  heroTitle2: "ավտոմեքենան",
  heroSub: "Հայաստանի ամենամեծ ավտոշուկան",

  make: "Մակնիշ",
  allMakes: "Բոլոր մակնիշները",

  model: "Մոդել",
  allModels: "Բոլոր մոդելները",

  yearFrom: "Թողարկման տարի (սկսած)",
  yearTo: "Թողարկման տարի (մինչև)",

  priceMin: "Գին (նվազագույն)",
  priceMax: "Գին (առավելագույն)",

  city: "Քաղաք",
  allCities: "Բոլոր քաղաքները",

  search: "Որոնել",

  statCars: "Ավտոմեքենաներ",
  statToday: "Ավելացվել է այսօր",
  statSellers: "Վաճառողներ",
  statCities: "Քաղաքներ",

  bodyType: "Թափքի տեսակ",
  price: "Գին",
  apply: "Կիրառել",

  carMakes: "Մակնիշներ",
  engine: "Շարժիչ",
  mileage: "Վազք (կմ)",
  transmission: "Փոխանցման տուփ",

  applyFilters: "Կիրառել ֆիլտրերը",

  featured: "Առաջարկվող հայտարարություններ",
  totalListings: "Հայտարարություններ — ընդհանուր",
  newAdded: "Նոր ավելացվածներ",

  sortNew: "Սկզբում նորերը",
  sortPriceUp: "Գին — աճման կարգով",
  sortPriceDown: "Գին — նվազման կարգով",
  sortMileage: "Վազք — նվազման կարգով",

  km: "կմ",
  today: "Այսօր",
  yesterday: "Երեկ",
  daysAgo: "օր առաջ",

  addFav: "Ավելացնել ընտրյալներին",
  remFav: "Հեռացնել ընտրյալներից",

  footerDesc: "Հայաստանի ամենամեծ ավտոմեքենաների շուկան։",
  footerCat: "Կատեգորիաներ",
  footerType: "Մեքենայի տեսակներ",
  footerClient: "Հաճախորդներին",

  footerLinks1: ["Ըստ մակնիշի", "Ըստ մոդելի", "Էլեկտրամեքենաներ", "Դիլերներ"],
  footerLinks2: ["Սեդան", "SUV / Jeep", "Հեչբեք", "Էլեկտրամեքենա"],
  footerLinks3: ["Ավելացնել հայտարարություն", "Ավտովարկ", "ՀՏՀ (FAQ)", "Կապ մեզ հետ"],

  copyright: "© 2025 HayDrive։ Բոլոր իրավունքները պաշտպանված են։",

  currency: "Արժույթ",
  filters: "Ֆիլտրեր",

  bodyTypes: [
    "Բոլորը",
    "Սեդան",
    "SUV / Jeep",
    "Հեչբեք",
    "Կուպե",
    "Մինիվեն",
    "Կաբրիոլետ",
    "Ֆուրգոն"
  ],
},

  ru: {
    country: "Армения",
    phone: "+374 10 123 456",
    hello: "Здравствуйте",
    login: "Войти",
    register: "Регистрация",
    nav: ["Автомобили", "Мотоциклы", "Грузовики", "Автобусы", "Запчасти", "Электро"],
    favorites: "Избранное",
    addListing: "+ Подать объявление",
    heroTitle: "Найдите свой",
    heroTitleSpan: "идеальный",
    heroTitle2: "автомобиль",
    heroSub: "Крупнейший авторынок Армении",
    make: "Марка", allMakes: "Все марки",
    model: "Модель", allModels: "Все модели",
    yearFrom: "Год выпуска (от)", yearTo: "Год выпуска (до)",
    priceMin: "Цена от", priceMax: "Цена до",
    city: "Город", allCities: "Все города",
    search: "Найти",
    statCars: "Автомобилей", statToday: "Добавлено сегодня", statSellers: "Продавцов", statCities: "Городов",
    bodyType: "Тип кузова", price: "Цена", apply: "Применить",
    carMakes: "Марка авто", engine: "Двигатель", mileage: "Пробег (км)", transmission: "КПП",
    applyFilters: "Применить фильтры",
    featured: "Премиум объявления", totalListings: "Объявлений всего", newAdded: "Новые объявления",
    sortNew: "Сначала новые", sortPriceUp: "Цена: по возрастанию", sortPriceDown: "Цена: по убыванию", sortMileage: "Пробег: по возрастанию",
    km: "км", today: "Сегодня", yesterday: "Вчера", daysAgo: "дн. назад",
    addFav: "В избранное", remFav: "Убрать",
    footerDesc: "Крупнейший авторынок Армении. Тысячи проверенных объявлений от частных лиц и дилеров.",
    footerCat: "Каталог", footerType: "Типы авто", footerClient: "Покупателям",
    footerLinks1: ["По марке", "По модели", "Электромобили", "Дилеры"],
    footerLinks2: ["Седан", "SUV / Jeep", "Хэтчбек", "Электро"],
    footerLinks3: ["Подать объявление", "Автокредит", "FAQ", "Контакты"],
    copyright: "© 2025 HayDrive. Все права защищены.",
    currency: "Валюта", filters: "Фильтры",
    bodyTypes: ["Все", "Седан", "SUV / Jeep", "Хэтчбек", "Купе", "Минивэн", "Кабриолет", "Фургон"],
  },

  en: {
    country: "Armenia",
    phone: "+374 10 123 456",
    hello: "Hello",
    login: "Sign In",
    register: "Register",
    nav: ["Cars", "Motorcycles", "Trucks", "Buses", "Parts", "Electric"],
    favorites: "Favorites",
    addListing: "+ Post Ad",
    heroTitle: "Find your",
    heroTitleSpan: "perfect",
    heroTitle2: "car",
    heroSub: "Armenia's largest automotive marketplace",
    make: "Make", allMakes: "All Makes",
    model: "Model", allModels: "All Models",
    yearFrom: "Year From", yearTo: "Year To",
    priceMin: "Price Min", priceMax: "Price Max",
    city: "City", allCities: "All Cities",
    search: "Search",
    statCars: "Cars", statToday: "Added Today", statSellers: "Sellers", statCities: "Cities",
    bodyType: "Body Type", price: "Price", apply: "Apply",
    carMakes: "Car Brands", engine: "Engine", mileage: "Mileage (km)", transmission: "Transmission",
    applyFilters: "Apply Filters",
    featured: "Premium Listings", totalListings: "Total Listings", newAdded: "Newest First",
    sortNew: "Newest", sortPriceUp: "Price: Low to High", sortPriceDown: "Price: High to Low", sortMileage: "Mileage: Low to High",
    km: "km", today: "Today", yesterday: "Yesterday", daysAgo: "days ago",
    addFav: "Save", remFav: "Saved",
    footerDesc: "Armenia's largest car marketplace. Thousands of verified listings from private sellers and dealers.",
    footerCat: "Catalog", footerType: "Car Types", footerClient: "For Buyers",
    footerLinks1: ["By Brand", "By Model", "Electric Cars", "Dealers"],
    footerLinks2: ["Sedan", "SUV / Jeep", "Hatchback", "Electric"],
    footerLinks3: ["Post Ad", "Car Loan", "FAQ", "Contact Us"],
    copyright: "© 2025 HayDrive. All rights reserved.",
    currency: "Currency", filters: "Filters",
    bodyTypes: ["All", "Sedan", "SUV / Jeep", "Hatchback", "Coupe", "Minivan", "Convertible", "Van"],
  },
};

export default T;
export const LANGUAGES = ["hy", "ru", "en"];
export const LANG_LABELS = { hy: "ՀԱՅ", ru: "РУС", en: "ENG" };
