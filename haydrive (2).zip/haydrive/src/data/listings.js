export const CARS = [
  { id: 1, make: "Toyota", model: "Camry", year: 2020, priceAMD: 12_500_000, km: 45_000, engine: "2.5L", trans: { hy: "Avtomat", ru: "Автомат", en: "Automatic" }, fuel: { hy: "Benzin", ru: "Бензин", en: "Petrol" }, city: { hy: "Yerevan", ru: "Ереван", en: "Yerevan" }, badge: "hot", daysAgo: 0 },
  { id: 2, make: "BMW", model: "3 Series", year: 2019, priceAMD: 18_900_000, km: 62_000, engine: "2.0L", trans: { hy: "Avtomat", ru: "Автомат", en: "Automatic" }, fuel: { hy: "Benzin", ru: "Бензин", en: "Petrol" }, city: { hy: "Gyumri", ru: "Гюмри", en: "Gyumri" }, badge: null, daysAgo: 1 },
  { id: 3, make: "Mercedes", model: "C220", year: 2021, priceAMD: 26_500_000, km: 28_000, engine: "2.0L", trans: { hy: "Avtomat", ru: "Автомат", en: "Automatic" }, fuel: { hy: "Dizel", ru: "Дизель", en: "Diesel" }, city: { hy: "Yerevan", ru: "Ереван", en: "Yerevan" }, badge: "new", daysAgo: 0 },
  { id: 4, make: "Hyundai", model: "Tucson", year: 2022, priceAMD: 16_800_000, km: 15_000, engine: "1.6T", trans: { hy: "Avtomat", ru: "Автомат", en: "Automatic" }, fuel: { hy: "Benzin", ru: "Бензин", en: "Petrol" }, city: { hy: "Vanadzor", ru: "Ванадзор", en: "Vanadzor" }, badge: "new", daysAgo: 2 },
  { id: 5, make: "Kia", model: "Sportage", year: 2021, priceAMD: 14_200_000, km: 33_000, engine: "2.0L", trans: { hy: "Avtomat", ru: "Автомат", en: "Automatic" }, fuel: { hy: "Benzin", ru: "Бензин", en: "Petrol" }, city: { hy: "Yerevan", ru: "Ереван", en: "Yerevan" }, badge: null, daysAgo: 3 },
  { id: 6, make: "Lexus", model: "RX 350", year: 2020, priceAMD: 29_900_000, km: 41_000, engine: "3.5L", trans: { hy: "Avtomat", ru: "Автомат", en: "Automatic" }, fuel: { hy: "Benzin", ru: "Бензин", en: "Petrol" }, city: { hy: "Yerevan", ru: "Ереван", en: "Yerevan" }, badge: null, daysAgo: 5 },
];

export const FEATURED_CARS = [
  { id: 101, name: "Toyota Land Cruiser 200", priceAMD: 52_000_000 },
  { id: 102, name: "Porsche Cayenne 2022",    priceAMD: 48_500_000 },
  { id: 103, name: "Range Rover Sport",       priceAMD: 45_000_000 },
];

export const BRANDS = ["Toyota", "BMW", "Mercedes", "Hyundai", "Kia", "Lexus", "Audi", "Honda", "Nissan", "Volkswagen"];

export const CITIES = {
  hy: ["Բոlорр qaghaqner", "Yerevan", "Gyumri", "Vanadzor", "Aparan", "Hrazdan", "Alaverdi"],
  ru: ["Все города", "Ереван", "Гюмри", "Ванадзор", "Апаран", "Раздан", "Алаверди"],
  en: ["All Cities", "Yerevan", "Gyumri", "Vanadzor", "Aparan", "Hrazdan", "Alaverdi"],
};

export const BODY_TYPE_COUNTS = ["24 891", "8 234", "6 102", "4 891", "1 432", "2 100", "312", "1 820"];
export const YEARS = [2024, 2023, 2022, 2021, 2020, 2019, 2018, 2017, 2016, 2015];
export const ENGINE_OPTIONS = ["1.0–1.5L", "1.6–2.0L", "2.1–3.0L", "3.0L+"];
export const MILEAGE_OPTIONS = {
  hy: ["0–30 000 km", "30–60 000 km", "60–100 000 km", "100 000+ km"],
  ru: ["0–30 000 км", "30–60 000 км", "60–100 000 км", "100 000+ км"],
  en: ["0–30,000 km", "30–60,000 km", "60–100,000 km", "100,000+ km"],
};
export const TRANSMISSION_OPTIONS = {
  hy: ["Avtomat", "Mekanik", "Variator"],
  ru: ["Автомат", "Механика", "Вариатор"],
  en: ["Automatic", "Manual", "CVT"],
};
