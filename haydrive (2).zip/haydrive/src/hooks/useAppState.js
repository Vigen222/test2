import { useState } from "react";

export function useAppState() {
  const [lang,      setLang]      = useState("ru");
  const [currency,  setCurrency]  = useState("AMD");
  const [view,      setView]      = useState("grid");
  const [activeCat, setActiveCat] = useState(0);
  const [selBrands, setSelBrands] = useState([]);
  const [favs,      setFavs]      = useState([]);
  const [page,      setPage]      = useState(1);
  const [activeNav, setActiveNav] = useState(0);

  const toggleBrand = (brand) =>
    setSelBrands((prev) =>
      prev.includes(brand) ? prev.filter((b) => b !== brand) : [...prev, brand]
    );

  const toggleFav = (id, e) => {
    e?.stopPropagation();
    setFavs((prev) =>
      prev.includes(id) ? prev.filter((x) => x !== id) : [...prev, id]
    );
  };

  const isFav = (id) => favs.includes(id);

  return {
    lang, setLang,
    currency, setCurrency,
    view, setView,
    activeCat, setActiveCat,
    selBrands, toggleBrand,
    favs, toggleFav, isFav,
    page, setPage,
    activeNav, setActiveNav,
  };
}
